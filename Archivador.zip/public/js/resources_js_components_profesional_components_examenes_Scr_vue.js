"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_components_profesional_components_examenes_Scr_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      items: [{
        id: '1',
        content: 'Dolores de cabeza'
      }, {
        id: '2',
        content: 'Nerviosismo o agitación interior'
      }, {
        id: '3',
        content: 'Pensamientos, palabras o ideas no deseadas que no se le van de su mente'
      }, {
        id: '4',
        content: 'Sensaciones de desmayo o mareo'
      }, {
        id: '5',
        content: 'Pérdida del deseo o del placer sexual'
      }, {
        id: '6',
        content: 'El hecho de juzgar a otras personas crítica o negativamente'
      }, {
        id: '7',
        content: 'La idea de que otra persona puede controlar sus pensamientos'
      }, {
        id: '8',
        content: 'La impresión de que la mayoría de sus problemas son culpa de los demá'
      }, {
        id: '9',
        content: 'Dificultad para recordar las cosas'
      }, {
        id: '10',
        content: 'Preocupaciones acerca del desaseo, el descuido o la desorganización'
      }, {
        id: '11',
        content: 'Sentirse fácilmente irritado o enfadado'
      }, {
        id: '12',
        content: 'Dolores en el corazón o en el pecho'
      }, {
        id: '13',
        content: 'Sentir miedo de los espacios abiertos o de la calle'
      }, {
        id: '14',
        content: 'Sentirse bajo de energías o decaído'
      }, {
        id: '15',
        content: 'Pensamientos o ideas de acabar con su vida'
      }, {
        id: '16',
        content: 'Oír voces que otras personas no oyen'
      }, {
        id: '17',
        content: 'Temblores'
      }, {
        id: '18',
        content: 'La idea de que no se puede fiar de la mayoría de las personas'
      }, {
        id: '19',
        content: 'Falta de apetito'
      }, {
        id: '20',
        content: 'Llorar fácilmente'
      }, {
        id: '21',
        content: 'Timidez o incomodidad con el sexo opuesto'
      }, {
        id: '22',
        content: 'La sensación de estar atrapado o como encerrado'
      }, {
        id: '23',
        content: 'Tener miedo de repente y sin razón'
      }, {
        id: '24',
        content: 'Arrebatos de cólera o ataques de furia que no logra controlar'
      }, {
        id: '25',
        content: 'Miedo a salir de casa solo'
      }, {
        id: '26',
        content: 'Culparse a sí mismo de lo que pasa'
      }, {
        id: '27',
        content: 'Dolores en la parte baja de la espalda'
      }, {
        id: '28',
        content: 'Sentirse incapaz de lograr cosas'
      }, {
        id: '29',
        content: 'Sentirse solo'
      }, {
        id: '30',
        content: 'Sentirse triste'
      }, {
        id: '31',
        content: 'Preocuparse demasiado por las cosas'
      }, {
        id: '32',
        content: 'No sentir interés por las cosas'
      }, {
        id: '33',
        content: 'Sentirse temeroso'
      }, {
        id: '34',
        content: 'Ser demasiado sensible o sentirse herido con facilidad'
      }, {
        id: '35',
        content: 'La impresión de que los demás se dan cuenta de sus pensamientos'
      }, {
        id: '36',
        content: 'La sensación de que los demás no le comprenden o no le hacen caso'
      }, {
        id: '37',
        content: 'La impresión de que la gente es poco amistosa o que usted no les gusta'
      }, {
        id: '38',
        content: 'Tener que hacer las cosas muy despacio para estar seguro de que las hace bien'
      }, {
        id: '39',
        content: 'Que el corazón le palpita o le vaya muy deprisa'
      }, {
        id: '40',
        content: 'Náuseas o malestar en el estómago'
      }, {
        id: '41',
        content: 'Sentirse inferior a los demás '
      }, {
        id: '42',
        content: 'Dolores musculares '
      }, {
        id: '43',
        content: 'Sensación de que otras personas le miran o hablan de usted '
      }, {
        id: '44',
        content: 'Dificultad para conciliar el sueño '
      }, {
        id: '45',
        content: 'Tener que comprobar una y otra vez lo que hace'
      }, {
        id: '46',
        content: 'Encontrar difícil el tomar decisiones '
      }, {
        id: '47',
        content: 'Sentir temor a viajar en coches, autobuses, metro, trenes, etc. '
      }, {
        id: '48',
        content: 'Dificultad para respirar '
      }, {
        id: '49',
        content: 'Sentir calor o frío de repente '
      }, {
        id: '50',
        content: 'Tener que evitar ciertas cosas, lugares o actividades por que le dan miedo '
      }, {
        id: '51',
        content: 'Que se le quede la mente en blanco '
      }, {
        id: '52',
        content: 'Entumecimiento u hormigueo en alguna parte del cuerpo '
      }, {
        id: '53',
        content: 'Sentir un nudo en la garganta'
      }, {
        id: '54',
        content: 'Sentirse desesperanzado con respecto al futuro '
      }, {
        id: '55',
        content: 'Tener dificultad para concentrarse '
      }, {
        id: '56',
        content: 'Sentirse débil en alguna parte del cuerpo '
      }, {
        id: '57',
        content: 'Sentirse tenso o agitado '
      }, {
        id: '58',
        content: 'Pesadez en los brazos o las piernas'
      }, {
        id: '59',
        content: 'Pensamientos sobre la muerte o el hecho de morir'
      }, {
        id: '60',
        content: 'El comer demasiado '
      }, {
        id: '61',
        content: 'Sentirse incomodo cuando la gente le mira o habla acerca de usted '
      }, {
        id: '62',
        content: 'Tener pensamientos que no son suyos'
      }, {
        id: '63',
        content: ' Sentir el impulso de golpear, herir o hacer daño a alguien'
      }, {
        id: '64',
        content: 'Despertarse de madrugada'
      }, {
        id: '65',
        content: 'Tener que repetir las mismas acciones tales como tocar, contar, lavar, etc.'
      }, {
        id: '66',
        content: 'Sueño inquieto o desvelarse fácilmente'
      }, {
        id: '67',
        content: 'Tener fuertes deseos de romper algo'
      }, {
        id: '68',
        content: 'Tener ideas o creencias que los demás no comparten'
      }, {
        id: '69',
        content: 'Sentirse muy cohibido entre otras personas'
      }, {
        id: '70',
        content: 'Sentirse muy incómodo entre mucha gente, p.ej. en el cine, en las tiendas'
      }, {
        id: '71',
        content: 'Sentir que todo requiere un gran esfuerzo'
      }, {
        id: '72',
        content: 'Ataques de terror o pánico'
      }, {
        id: '73',
        content: 'Sentirse incómodo comiendo o bebiendo en público '
      }, {
        id: '74',
        content: 'Tener discusiones frecuentes'
      }, {
        id: '75',
        content: 'Sentirse nervioso cuando se encuentra solo'
      }, {
        id: '76',
        content: 'El que otros no reconozcan adecuadamente sus logros'
      }, {
        id: '77',
        content: 'Sentirse solo aunque esté con más gente'
      }, {
        id: '78',
        content: 'Sentirse tan inquieto que no puede ni estar sentado tranquilo'
      }, {
        id: '79',
        content: 'La sensación de ser inútil o de no valer nada'
      }, {
        id: '80',
        content: 'Pensamientos de que va a pasar algo malo '
      }, {
        id: '81',
        content: 'Tener deseos de gritar o de tirar cosas'
      }, {
        id: '82',
        content: 'Tener miedo de desmayarse en público'
      }, {
        id: '83',
        content: 'La impresión de que la gente intentaría aprovecharse de usted si les dejara'
      }, {
        id: '84',
        content: 'Tener pensamientos sobre el sexo que le inquietan bastante'
      }, {
        id: '85',
        content: 'La idea de que debería ser castigado por sus pecados'
      }, {
        id: '86',
        content: 'Pensamientos o imágenes estremecedoras que le dan miedo'
      }, {
        id: '87',
        content: 'La idea de que algo anda mal en su cuerpo'
      }, {
        id: '88',
        content: 'No sentirse cercano o íntimo con nadie'
      }, {
        id: '89',
        content: 'Sentimientos de culpabilidad '
      }, {
        id: '90',
        content: 'La idea de que algo anda mal en su mente'
      }],
      somat: 0,
      obses: 0,
      sensib: 0,
      depre: 0,
      ansi: 0,
      hostil: 0,
      ansi_fob: 0,
      paranoid: 0,
      psicot: 0,
      igs: 0,
      sp: 0,
      psdi: 0,
      objs: [],
      sexo: '',
      buscar: '',
      showResults: false,
      patients: [],
      patient_id: '',
      verResultados: false
    };
  },
  methods: {
    inputValue: function inputValue(nro) {
      var name = 'inlineRadioOptions' + nro;
      var rpta = document.querySelector('input[name=' + name + ']:checked').value;
      var obj = {
        nro: nro,
        rpta: rpta
      };
      if (this.verifDuplicated(obj)) {
        this.objs.push(_objectSpread({}, obj));
      } else {}
      //console.log(this.objs)

      /* var filter = this.objs.filter(obj => obj.nro == nro)
      console.log(filter)
      if(filter.lenght != 0){
      	this.objs.splice(obj,1)
      	obj= {nro, rpta}
      	this.objs.push({...obj})
      }else{
      	}
      	console.log(this.objs) */
    },
    verifDuplicated: function verifDuplicated(obj2) {
      if (this.objs.filter(function (obj) {
        return obj.nro == obj2.nro;
      }).length == 0) {
        return true;
      } else {
        console.log('coincidencia de nro');
        this.objs = this.objs.filter(function (obj) {
          return obj.nro != obj2.nro;
        });
        this.objs.push(_objectSpread({}, obj2));
        return false;
      }
    },
    sumatoria: function sumatoria() {
      var _this = this;
      this.somat = 0, this.obses = 0, this.sensib = 0, this.depre = 0, this.ansi = 0, this.hostil = 0, this.ansi_fob = 0, this.paranoid = 0, this.psicot = 0, this.igs = 0, this.sp = 0;
      this.objs.forEach(function (value, index) {
        var nro = value.nro;
        var rpta = value.rpta;
        _this.igs += parseInt(rpta);
        if (rpta != 0) {
          _this.sp += 1;
        }
        if (nro == 1 || nro == 4 || nro == 12 || nro == 27 || nro == 40 || nro == 42 || nro == 48 || nro == 49 || nro == 52 || nro == 53 || nro == 56 || nro == 58) {
          _this.somat += parseInt(rpta);
        } else if (nro == 3 || nro == 9 || nro == 10 || nro == 28 || nro == 38 || nro == 45 || nro == 46 || nro == 51 || nro == 55 || nro == 65) {
          _this.obses += parseInt(rpta);
        } else if (nro == 6 || nro == 21 || nro == 34 || nro == 36 || nro == 37 || nro == 41 || nro == 61 || nro == 69 || nro == 73) {
          _this.sensib += parseInt(rpta);
        } else if (nro == 5 || nro == 14 || nro == 15 || nro == 20 || nro == 22 || nro == 26 || nro == 29 || nro == 30 || nro == 31 || nro == 32 || nro == 54 || nro == 71 || nro == 79) {
          _this.depre += parseInt(rpta);
        } else if (nro == 2 || nro == 17 || nro == 23 || nro == 33 || nro == 39 || nro == 57 || nro == 72 || nro == 78 || nro == 80 || nro == 86) {
          _this.ansi += parseInt(rpta);
        } else if (nro == 74 || nro == 81 || nro == 67 || nro == 63 || nro == 24 || nro == 11) {
          _this.hostil += parseInt(rpta);
        } else if (nro == 13 || nro == 25 || nro == 47 || nro == 50 || nro == 75 || nro == 82) {
          _this.ansi_fob += parseInt(rpta);
        } else if (nro == 8 || nro == 18 || nro == 43 || nro == 68 || nro == 76 || nro == 83) {
          _this.paranoid += parseInt(rpta);
        } else if (nro == 7 || nro == 16 || nro == 35 || nro == 62 || nro == 77 || nro == 84 || nro == 85 || nro == 87 || nro == 88 || nro == 90) {
          _this.psicot += parseInt(rpta);
        }
      });
      this.psdi = this.igs / this.sp;
      this.igs = this.igs / 90;
      this.somat = this.somat / 12;
      this.obses = this.obses / 10;
      this.sensib = this.sensib / 9;
      this.depre = this.depre / 13;
      this.ansi = this.ansi / 10;
      this.hostil = this.hostil / 6;
      this.ansi_fob = this.ansi_fob / 6;
      this.paranoid = this.paranoid / 6;
      this.psicot = this.psicot / 10;
      if (this.sexo == 'M') {
        //Somatizacion
        if (this.somat >= 1.49) {
          this.somat = 80;
        } else if (this.somat >= 0.81) {
          this.somat = 65;
        } else if (this.somat >= 0.25) {
          this.somat = 50;
        } else if (this.somat >= 0) {
          this.somat = 35;
        }
        //Obsesión
        if (this.obses >= 2.51) {
          this.obses = 80;
        } else if (this.obses >= 1.49) {
          this.obses = 65;
        } else if (this.obses >= 0.495) {
          this.obses = 50;
        } else if (this.obses >= 0) {
          this.obses = 35;
        }
        //Sensibilidad
        if (this.sensib >= 2.025) {
          this.sensib = 80;
        } else if (this.sensib >= 1.175) {
          this.sensib = 65;
        } else if (this.sensib >= 0.38) {
          this.sensib = 50;
        } else if (this.sensib >= 0) {
          this.sensib = 35;
        }
        //Depresión
        if (this.depre >= 1.775) {
          this.depre = 80;
        } else if (this.depre >= 1.025) {
          this.depre = 65;
        } else if (this.depre >= 0.33) {
          this.depre = 50;
        } else if (this.depre >= 0) {
          this.depre = 35;
        }
        //Ansiedad
        if (this.ansi >= 1.75) {
          this.ansi = 80;
        } else if (this.ansi >= 0.95) {
          this.ansi = 65;
        } else if (this.ansi >= 0.28) {
          this.ansi = 50;
        } else if (this.ansi >= 0) {
          this.ansi = 35;
        }
        //Hostilidad
        if (this.hostil >= 2.7) {
          this.hostil = 80;
        } else if (this.hostil >= 1.5) {
          this.hostil = 65;
        } else if (this.hostil >= 0.455) {
          this.hostil = 50;
        } else if (this.hostil >= 0) {
          this.hostil = 35;
        }
        //Ansiedad Fóbica
        if (this.ansi_fob >= 1.29) {
          this.ansi_fob = 80;
        } else if (this.ansi_fob >= 0.61) {
          this.ansi_fob = 65;
        } else if (this.ansi_fob >= 0.14) {
          this.ansi_fob = 50;
        } else if (this.ansi_fob >= 0) {
          this.ansi_fob = 35;
        }
        //Ideacion Paranoide
        if (this.paranoid >= 2.4) {
          this.paranoid = 80;
        } else if (this.paranoid >= 1.3) {
          this.paranoid = 65;
        } else if (this.paranoid >= 0.38) {
          this.paranoid = 50;
        } else if (this.paranoid >= 0) {
          this.paranoid = 35;
        }
        //Psicoticismo
        if (this.psicot >= 1.95) {
          this.psicot = 80;
        } else if (this.psicot >= 0.75) {
          this.psicot = 65;
        } else if (this.psicot >= 0.205) {
          this.psicot = 50;
        } else if (this.psicot >= 0) {
          this.psicot = 35;
        }
        //IGS
        if (this.igs >= 0.295) {
          this.igs = 80;
        } else if (this.igs >= 0.165) {
          this.igs = 65;
        } else if (this.igs >= 0.055) {
          this.igs = 50;
        } else if (this.igs >= 0) {
          this.igs = 35;
        }
        //PSDI
        if (this.psdi >= 3.015) {
          this.psdi = 80;
        } else if (this.psdi >= 2.185) {
          this.psdi = 65;
        } else if (this.psdi >= 1.355) {
          this.psdi = 50;
        } else if (this.psdi >= 0) {
          this.psdi = 35;
        }
        //Sintomas positivos
        if (this.sp >= 73) {
          this.sp = 80;
        } else if (this.sp >= 53) {
          this.sp = 65;
        } else if (this.sp >= 33) {
          this.sp = 50;
        } else if (this.sp >= 0) {
          this.sp = 35;
        }
      } else {
        //Somatizacion
        if (this.somat >= 1.95) {
          this.somat = 80;
        } else if (this.somat >= 1.25) {
          this.somat = 65;
        } else if (this.somat >= 0.65) {
          this.somat = 50;
        } else if (this.somat >= 0) {
          this.somat = 35;
        }
        //Obsesión
        if (this.obses >= 3.11) {
          this.obses = 80;
        } else if (this.obses >= 1.89) {
          this.obses = 65;
        } else if (this.obses >= 0.72) {
          this.obses = 50;
        } else if (this.obses >= 0) {
          this.obses = 35;
        }
        //Sensibilidad
        if (this.sensib >= 3) {
          this.sensib = 80;
        } else if (this.sensib >= 1.81) {
          this.sensib = 65;
        } else if (this.sensib >= 0.66) {
          this.sensib = 50;
        } else if (this.sensib >= 0) {
          this.sensib = 35;
        }
        //Depresión
        if (this.depre >= 3) {
          this.depre = 80;
        } else if (this.depre >= 1.8) {
          this.depre = 65;
        } else if (this.depre >= 0.605) {
          this.depre = 50;
        } else if (this.depre >= 0) {
          this.depre = 35;
        }
        //Ansiedad
        if (this.ansi >= 2.9) {
          this.ansi = 80;
        } else if (this.ansi >= 1.75) {
          this.ansi = 65;
        } else if (this.ansi >= 0.555) {
          this.ansi = 50;
        } else if (this.ansi >= 0) {
          this.ansi = 35;
        }
        //Hostilidad
        if (this.hostil >= 3.05) {
          this.hostil = 80;
        } else if (this.hostil >= 1.75) {
          this.hostil = 65;
        } else if (this.hostil >= 0.555) {
          this.hostil = 50;
        } else if (this.hostil >= 0) {
          this.hostil = 35;
        }
        //Ansiedad Fóbica
        if (this.ansi_fob >= 1.85) {
          this.ansi_fob = 80;
        } else if (this.ansi_fob >= 0.95) {
          this.ansi_fob = 65;
        } else if (this.ansi_fob >= 0.255) {
          this.ansi_fob = 50;
        } else if (this.ansi_fob >= 0) {
          this.ansi_fob = 35;
        }
        //Ideacion Paranoide
        if (this.paranoid >= 3.05) {
          this.paranoid = 80;
        } else if (this.paranoid >= 1.735) {
          this.paranoid = 65;
        } else if (this.paranoid >= 0.54) {
          this.paranoid = 50;
        } else if (this.paranoid >= 0) {
          this.paranoid = 35;
        }
        //Psicoticismo
        if (this.psicot >= 2.2) {
          this.psicot = 80;
        } else if (this.psicot >= 1.2) {
          this.psicot = 65;
        } else if (this.psicot >= 0.355) {
          this.psicot = 50;
        } else if (this.psicot >= 0) {
          this.psicot = 35;
        }
        //IGS
        if (this.igs >= 0.41) {
          this.igs = 80;
        } else if (this.igs >= 0.25) {
          this.igs = 65;
        } else if (this.igs >= 0.09) {
          this.igs = 50;
        } else if (this.igs >= 0) {
          this.igs = 35;
        }
        //PSDI
        if (this.psdi >= 3.2) {
          this.psdi = 80;
        } else if (this.psdi >= 2.385) {
          this.psdi = 65;
        } else if (this.psdi >= 1.555) {
          this.psdi = 50;
        } else if (this.psdi >= 0) {
          this.psdi = 35;
        }
        //Sintomas positivos
        if (this.sp >= 73) {
          this.sp = 80;
        } else if (this.sp >= 53) {
          this.sp = 65;
        } else if (this.sp >= 33) {
          this.sp = 50;
        } else if (this.sp >= 0) {
          this.sp = 35;
        }
      }
      var config = {
        headers: {
          'content-type': 'multipart/form-data'
        }
      };
      var formData = new FormData();
      formData.append('somatization', this.somat);
      formData.append('obsession', this.obses);
      formData.append('interpersonal_sensitivity', this.sensib);
      formData.append('depression', this.depre);
      formData.append('anxiety', this.ansi);
      formData.append('hostility', this.hostil);
      formData.append('phobic_anxiety', this.ansi_fob);
      formData.append('paranoid_ideation', this.paranoid);
      formData.append('psychoticism', this.psicot);
      formData.append('igs', this.igs);
      formData.append('sp', this.sp);
      formData.append('psdi', this.psdi);
      formData.append('patient_id', this.patient_id);
      formData.append('professional_id', this.$attrs.dataUser.id);
      formData.append('resultados', JSON.stringify(this.objs));
      this.axios.post('/api/saveScr', formData, config).then(function (result) {
        _this.$swal('Resultados regitrados correctamente');
      })["catch"](function (err) {
        _this.$swal({
          icon: 'error',
          title: 'Error...',
          text: err
        });
      });
    },
    print: function print() {
      window.print();
    },
    getNames: function getNames() {
      var _this2 = this;
      this.axios.get('/api/getNames').then(function (result) {
        _this2.patients = result.data;
        //console.log(this.patients)
      })["catch"](function (err) {});
    },
    selectPatient: function selectPatient(patient) {
      this.$swal('Usuario aceptado');
      this.patient_id = patient.id;
      this.buscar = patient.name;
      this.showResults = false;
    },
    queRespuesta: function queRespuesta(id) {
      //buscamos la si tiene respuesta a la pregunta
      var resp = this.objs.filter(function (x) {
        return x.nro == id;
      });
      console.log('resp', resp);
      if (resp.length > 0) switch (resp[0].rpta) {
        case '0':
          return 'A: Nada';
          break;
        case '1':
          return 'B: Un poco';
          break;
        case '2':
          return 'C: Moderadamente';
          break;
        case '3':
          return 'D: Bastante';
          break;
        case '4':
          return 'E: Mucho';
          break;
        default:
          return 'Sin respuesta registrada';
          break;
      } else return 'Sin respuesta registrada';
    }
  },
  computed: {
    filtro: function filtro() {
      var _this3 = this;
      if (!this.buscar) {
        this.showResults = false;
        return null;
      } else {
        this.showResults = true;
        return this.patients.filter(function (patient) {
          return patient.name.toLowerCase().includes(_this3.buscar);
        }).slice(0, 6);
      }
    }
  },
  mounted: function mounted() {
    var _this4 = this;
    if (this.$route.params.id) {
      this.axios.post('/api/pedirResultadosExamen/', {
        examen: 'scr',
        id: this.$route.params.id
      }).then(function (resp) {
        _this4.objs = JSON.parse(resp.data.resultados);
      });
      this.verResultados = true;
    } else this.verResultados = false;
    this.getNames();
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=template&id=410e50c4&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=template&id=410e50c4&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* binding */ render),
/* harmony export */   staticRenderFns: () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("main", [_c("h1", [_vm._v("SCL-90R "), _vm.verResultados ? _c("span", [_vm._v("- RESULTADOS")]) : _vm._e()]), _vm._v(" "), !_vm.verResultados ? _c("div", {
    staticClass: "scrollable"
  }, [_vm._v("\n\t\tSomatizacion:  " + _vm._s(this.somat) + "\n\t\t"), _c("br"), _vm._v("\n\t\tObsesion- Compulsion: " + _vm._s(this.obses) + "\n\t\t"), _c("br"), _vm._v("\n\t\tSensibilidad interpersonal: " + _vm._s(this.sensib) + "\n\t\t"), _c("br"), _vm._v("\n\t\tDepresión: " + _vm._s(this.depre) + "\n\t\t"), _c("br"), _vm._v("\n\t\tAnsiedad: " + _vm._s(this.ansi) + "\n\t\t"), _c("br"), _vm._v("\n\t\tHostilidad: " + _vm._s(this.hostil) + "\n\t\t"), _c("br"), _vm._v("\n\t\tAnsiedad fóbica: " + _vm._s(this.ansi_fob) + "\n\t\t"), _c("br"), _vm._v("\n\t\tIdeación paranoide: " + _vm._s(this.paranoid) + "\n\t\t"), _c("br"), _vm._v("\n\t\tPsicoticismo:   " + _vm._s(this.psicot) + "\n\t\t"), _c("br"), _vm._v("\n\t\tIGS: " + _vm._s(this.igs) + "\n\t\t"), _c("br"), _vm._v("\n\t\tSP: " + _vm._s(this.sp) + "\n\t\t"), _c("br"), _vm._v("\n\t\tPSDI: " + _vm._s(this.psdi) + "\n\t\t"), _c("br"), _vm._v(" "), !_vm.verResultados ? _c("button", {
    staticClass: "btn btn-primary",
    on: {
      click: _vm.sumatoria
    }
  }, [_vm._v("Calcular y guardar")]) : _vm._e()]) : _vm._e(), _vm._v(" "), !_vm.verResultados ? _c("div", [_c("label", {
    attrs: {
      "for": ""
    }
  }, [_vm._v("Nombre del Paciente")]), _vm._v(" "), _c("div", {
    staticClass: "d-flex gap flex-wrap"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.buscar,
      expression: "buscar"
    }],
    staticClass: "form-control input-name",
    attrs: {
      type: "text",
      name: "",
      id: ""
    },
    domProps: {
      value: _vm.buscar
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.buscar = $event.target.value;
      }
    }
  }), _vm._v(" "), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showResults,
      expression: "showResults"
    }],
    staticClass: "border border-secondary shadow w-100"
  }, _vm._l(_vm.filtro, function (patient) {
    return _c("div", {
      key: patient.id,
      staticClass: "border border-secondary",
      on: {
        click: function click($event) {
          return _vm.selectPatient(patient);
        }
      }
    }, [_vm._v(_vm._s(patient.name) + " " + _vm._s(patient.nombres))]);
  }), 0), _vm._v(" "), _c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.sexo,
      expression: "sexo"
    }],
    staticClass: "form-select input-select",
    attrs: {
      name: "",
      id: ""
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.sexo = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, [_c("option", {
    attrs: {
      value: ""
    }
  }, [_vm._v("Sexo")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "M"
    }
  }, [_vm._v("Varon")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "F"
    }
  }, [_vm._v("Mujer")])])])]) : _vm._e(), _vm._v(" "), _vm._m(0), _vm._v(" "), _c("ul", {
    staticClass: "p-0"
  }, _vm._l(_vm.items, function (item) {
    return _c("li", {
      key: item.id
    }, [_vm._v("\n\t\t   " + _vm._s(item.id) + ". " + _vm._s(item.content) + "\n\t\t   "), _c("br"), _vm._v(" "), !_vm.verResultados ? _c("div", [_c("div", {
      staticClass: "form-check form-check-inline",
      on: {
        click: function click($event) {
          return _vm.inputValue(item.id);
        }
      }
    }, [_c("input", {
      staticClass: "form-check-input",
      attrs: {
        type: "radio",
        name: "inlineRadioOptions".concat(item.id),
        id: "inlineRadio".concat(item.id, "-a"),
        value: "0"
      }
    }), _vm._v(" "), _c("label", {
      staticClass: "form-check-label",
      attrs: {
        "for": "inlineRadio".concat(item.id, "-a")
      }
    }, [_vm._v("A")])]), _vm._v(" "), _c("div", {
      staticClass: "form-check form-check-inline",
      on: {
        click: function click($event) {
          return _vm.inputValue(item.id);
        }
      }
    }, [_c("input", {
      staticClass: "form-check-input",
      attrs: {
        type: "radio",
        name: "inlineRadioOptions".concat(item.id),
        id: "inlineRadio".concat(item.id, "-b"),
        value: "1"
      }
    }), _vm._v(" "), _c("label", {
      staticClass: "form-check-label",
      attrs: {
        "for": "inlineRadio".concat(item.id, "-b")
      }
    }, [_vm._v("B")])]), _vm._v(" "), _c("div", {
      staticClass: "form-check form-check-inline",
      on: {
        click: function click($event) {
          return _vm.inputValue(item.id);
        }
      }
    }, [_c("input", {
      staticClass: "form-check-input",
      attrs: {
        type: "radio",
        name: "inlineRadioOptions".concat(item.id),
        id: "inlineRadio".concat(item.id, "-c"),
        value: "2"
      }
    }), _vm._v(" "), _c("label", {
      staticClass: "form-check-label",
      attrs: {
        "for": "inlineRadio".concat(item.id, "-c")
      }
    }, [_vm._v("C")])]), _vm._v(" "), _c("div", {
      staticClass: "form-check form-check-inline",
      on: {
        click: function click($event) {
          return _vm.inputValue(item.id);
        }
      }
    }, [_c("input", {
      staticClass: "form-check-input",
      attrs: {
        type: "radio",
        name: "inlineRadioOptions".concat(item.id),
        id: "inlineRadio".concat(item.id, "-d"),
        value: "3"
      }
    }), _vm._v(" "), _c("label", {
      staticClass: "form-check-label",
      attrs: {
        "for": "inlineRadio".concat(item.id, "-d")
      }
    }, [_vm._v("D")])]), _vm._v(" "), _c("div", {
      staticClass: "form-check form-check-inline",
      on: {
        click: function click($event) {
          return _vm.inputValue(item.id);
        }
      }
    }, [_c("input", {
      staticClass: "form-check-input",
      attrs: {
        type: "radio",
        name: "inlineRadioOptions".concat(item.id),
        id: "inlineRadio".concat(item.id, "-e"),
        value: "4"
      }
    }), _vm._v(" "), _c("label", {
      staticClass: "form-check-label",
      attrs: {
        "for": "inlineRadio".concat(item.id, "-e")
      }
    }, [_vm._v("E")])])]) : _c("div", [_c("small", {
      staticClass: "text-dark"
    }, [_vm._v("Marcado = " + _vm._s(_vm.queRespuesta(item.id)))])])]);
  }), 0), _vm._v(" "), _c("button", {
    staticClass: "btn btn-success",
    on: {
      click: _vm.print
    }
  }, [_vm._v("Imprimir Respuestas")])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "mt-2"
  }, [_vm._v("\n\t   ¿HASTA QUE PUNTO SE HA SENTIDO AFECTADO POR:?\n\t   Utilice los siguientes criterios:\n\t   "), _c("br"), _vm._v("\n\t   A: Nada B: Un poco C: Moderadamente D: Bastante E: Mucho\n\t")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/laravel-mix/node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/laravel-mix/node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_laravel_mix_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../../node_modules/laravel-mix/node_modules/css-loader/dist/runtime/api.js */ "./node_modules/laravel-mix/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_laravel_mix_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_laravel_mix_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_laravel_mix_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\nul[data-v-410e50c4]{\n\tlist-style: none;\n}\nli[data-v-410e50c4]{\n\tbackground-color: #fff;\n\tfont-size: 20px;\n\tborder: 1px solid rgba(0, 0, 0, 0.493);\n\tmargin: 10px 0px 10px 0px;\n\tborder-radius: 5px;\n\tpadding: 10px;\n}\n.input-name[data-v-410e50c4] {\n\twidth: 70%;\n\tflex: 1 0 auto;\n\tmin-width: 250px;\n}\n.input-select[data-v-410e50c4] {\n\twidth: 25%;\n\tflex: 1 0 auto;\n}\n.scrollable[data-v-410e50c4]{\n\tbackground-color: #fff;\n\tcolor: #000;\n\tposition: fixed;\n\tright: 0;\n\tborder: 1px solid rgba(0, 0, 0, 0.493);\n\tz-index:99;\n\tborder-radius: 5px;\n\tpadding: 5px;\n}\n.gap[data-v-410e50c4] {\n\tgap: 15px;\n}\n@media screen and (max-width: 750px) {\n.scrollable[data-v-410e50c4] {\n\t\tposition: relative;\n}\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/laravel-mix/node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/laravel-mix/node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_laravel_mix_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_style_index_0_id_410e50c4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../../node_modules/laravel-mix/node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css */ "./node_modules/laravel-mix/node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_laravel_mix_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_style_index_0_id_410e50c4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_laravel_mix_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_style_index_0_id_410e50c4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/profesional/components/examenes/Scr.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/components/profesional/components/examenes/Scr.vue ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Scr_vue_vue_type_template_id_410e50c4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Scr.vue?vue&type=template&id=410e50c4&scoped=true */ "./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=template&id=410e50c4&scoped=true");
/* harmony import */ var _Scr_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Scr.vue?vue&type=script&lang=js */ "./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=script&lang=js");
/* harmony import */ var _Scr_vue_vue_type_style_index_0_id_410e50c4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css */ "./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Scr_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _Scr_vue_vue_type_template_id_410e50c4_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render,
  _Scr_vue_vue_type_template_id_410e50c4_scoped_true__WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "410e50c4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/profesional/components/examenes/Scr.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=script&lang=js":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Scr.vue?vue&type=script&lang=js */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=script&lang=js");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=template&id=410e50c4&scoped=true":
/*!*******************************************************************************************************************!*\
  !*** ./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=template&id=410e50c4&scoped=true ***!
  \*******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_template_id_410e50c4_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   staticRenderFns: () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_template_id_410e50c4_scoped_true__WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_template_id_410e50c4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Scr.vue?vue&type=template&id=410e50c4&scoped=true */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=template&id=410e50c4&scoped=true");


/***/ }),

/***/ "./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css":
/*!*********************************************************************************************************************************!*\
  !*** ./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css ***!
  \*********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_laravel_mix_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Scr_vue_vue_type_style_index_0_id_410e50c4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader/dist/cjs.js!../../../../../../node_modules/laravel-mix/node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css */ "./node_modules/style-loader/dist/cjs.js!./node_modules/laravel-mix/node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/profesional/components/examenes/Scr.vue?vue&type=style&index=0&id=410e50c4&scoped=true&lang=css");


/***/ })

}]);