INSERT INTO `payment_method` (`id`, `tipo`) VALUES (NULL, 'Open Pay'), (NULL, 'Izipay');
