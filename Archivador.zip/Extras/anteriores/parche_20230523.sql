ALTER TABLE `triaje` ADD `peso` FLOAT NULL DEFAULT '0' AFTER `activo`, ADD `talla` FLOAT NULL DEFAULT '0' AFTER `peso`;
