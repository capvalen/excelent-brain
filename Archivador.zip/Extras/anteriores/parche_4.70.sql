UPDATE `seguimientos` SET `color` = 'text-muted' WHERE `seguimientos`.`id` = 1;
