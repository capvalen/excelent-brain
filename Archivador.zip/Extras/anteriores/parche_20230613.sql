UPDATE `users` SET `activo` = '0' WHERE `users`.`id` = 20;
