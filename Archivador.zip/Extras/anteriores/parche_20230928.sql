ALTER TABLE `faltas` ADD `idCita` INT NULL DEFAULT '0' AFTER `idPaciente`;
