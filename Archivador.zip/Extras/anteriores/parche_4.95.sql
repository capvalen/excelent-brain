ALTER TABLE `acontecimientos` CHANGE `sintomas` `sintomas` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL;
ALTER TABLE `acontecimientos` CHANGE `acontecimiento` `acontecimiento` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL;
