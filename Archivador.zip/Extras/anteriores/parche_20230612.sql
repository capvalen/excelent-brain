ALTER TABLE `extra_payments` ADD `razon` VARCHAR(250) NULL DEFAULT '' AFTER `user_id`;
