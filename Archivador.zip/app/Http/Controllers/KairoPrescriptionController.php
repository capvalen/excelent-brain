<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kairo_prescription;
use Illuminate\Support\Facades\DB;

class KairoPrescriptionController extends Controller
{
    //
}
