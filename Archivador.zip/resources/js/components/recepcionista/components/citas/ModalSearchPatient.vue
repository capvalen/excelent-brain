<template>
	<!-- Modal -->
<div class="modal fade" id="modalBuscarPacienteExterno" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Búsqueda del paciente</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <label for="">Busque por DNI o Nombres</label>
				<input type="text" class="form-control" v-model="texto" @keypress.enter="buscarTexto()">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
</template>
<script>
export default{
	name: 'ModalBuscarPacienteExterno',
	data(){ return {
		texto: ''
	}},
	methods:{
		buscarTexto(){}
	}
}</script>