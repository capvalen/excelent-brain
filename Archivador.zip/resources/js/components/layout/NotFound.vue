<template>
  <div>
    <h1>Pagina no encontrada</h1>
    <router-link to="/">Volver a la pagina de Inicio</router-link>
  </div>
</template>