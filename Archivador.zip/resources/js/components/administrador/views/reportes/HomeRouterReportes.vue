<template>
  <main>
    <h4>Reportes</h4>
    <router-view></router-view>
  </main>
</template>

<script>

</script>
